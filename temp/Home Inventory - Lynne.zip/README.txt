I have all the files installed in C:\xampp\htdocs\az\

If you use the URL:

http://localhost/az/index.php

It will default to pulling the data from the file: 1.json

If you add "id" to the end, like:

http://localhost/az/index.php?id=1
http://localhost/az/index.php?id=2
http://localhost/az/index.php?id=3

It will pull from the corresponding #.json file.